export const enableUserValid = process.env.FEATURES_ENV !== 'stable'
