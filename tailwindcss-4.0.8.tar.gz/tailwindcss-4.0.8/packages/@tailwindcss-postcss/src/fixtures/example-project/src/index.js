const className = 'text-2xl text-black/50'
