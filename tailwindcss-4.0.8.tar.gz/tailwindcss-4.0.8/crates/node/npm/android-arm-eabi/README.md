# `@tailwindcss/oxide-android-arm-eabi`

This is the **armv7-linux-android-eabi** binary for `@tailwindcss/oxide`
